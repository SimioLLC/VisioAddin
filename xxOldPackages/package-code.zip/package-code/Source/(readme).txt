Both SdxHarness and Visio2018 (add-in) use the two DLL project:
1. SdxHelpers
2. SdxVisio

You may have to reorganize the project references.

Let me know via forum if you need assistance.
Thanks,
Dan


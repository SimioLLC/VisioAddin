This package contains all of the source and binaries for the Simio Visio2018 Add-In.

The "To..." contains files that should be moved to subfolders of your user Documents folder.
"My Shapes" contains the Simio Facility Visio Stencil.
"SimioUserExtensions" of course contains the files needed for the Add-In.

There is a 5 minutes video at the top level that illustrates the usage of this.

There is more detailed information in the Documentation folder.

This is a preview of the Visio Add-In. All comments and suggestions are welcome and appreciated.


- Dan (6Aug2018)



